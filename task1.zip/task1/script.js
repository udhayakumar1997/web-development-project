const a=document.querySelector(".about");
const b=document.querySelector(".about1");
b.addEventListener('click',function(){
    if(a.style.display=="none")
    {
        a.style.display="block";
    }
    else{
        a.style.display="none";
    }
})





